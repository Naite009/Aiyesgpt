export async function verifyStepImage(opts: { imageBase64: string; stepText: string; userAction?: string }) {
  const url = import.meta.env.VITE_VERIFY_STEP_FUNCTION_URL || "/functions/v1/verify_step";
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ image: opts.imageBase64, instruction_step: opts.stepText, user_action: opts.userAction }),
  });
  if (!res.ok) throw new Error(`verify_step failed: ${res.status}`);
  return (await res.json()) as { confidence: number; feedback: string };
}

export function parseStepsFromMarkdown(md: string): string[] {
  return md
    .split(/\n+/)
    .map((l) => l.trim())
    .filter((l) => /^[-*]|^\d+\./.test(l))
    .map((l) => l.replace(/^[-*]\s*/, "").replace(/^\d+\.\s*/, ""));
}
