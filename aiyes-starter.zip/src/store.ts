import { useEffect, useState } from "react";
import type { Instruction, UserProgress, VerificationResult } from "./types";

export function useAppStore() {
  const [darkMode, setDarkMode] = useState(true);
  const [instructions, setInstructions] = useState<Instruction[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [userProgress, setUserProgress] = useState<Record<string, UserProgress>>({});

  useEffect(() => {
    // TODO: fetch initial public instructions from Supabase
  }, []);

  const updateProgress = (
    instructionId: string,
    updater: (prev: UserProgress | undefined) => UserProgress
  ) => {
    setUserProgress((prev) => ({ ...prev, [instructionId]: updater(prev[instructionId]) }));
  };

  const addVerification = (instructionId: string, result: VerificationResult) => {
    updateProgress(instructionId, (prev) => ({
      userId: "me",
      instructionId,
      currentStep: prev?.currentStep ?? 0,
      completedSteps: prev?.completedSteps ?? [],
      verificationResults: [...(prev?.verificationResults ?? []), result],
    }));
  };

  return {
    darkMode,
    setDarkMode,
    instructions,
    setInstructions,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    userProgress,
    updateProgress,
    addVerification,
  };
}
