import { useParams } from "react-router-dom";
import { useCamera, CameraPreview } from "@/components/Camera";
import { useEffect, useMemo, useState } from "react";
import { parseStepsFromMarkdown, verifyStepImage } from "@/services/ai";

export default function Guided() {
  const { id } = useParams();
  // TODO: fetch instruction by id
  const [title] = useState("Demo Instruction");
  const [md] = useState("1. Hold a cup\n2. Place cup on table");
  const steps = useMemo(() => parseStepsFromMarkdown(md), [md]);
  const [current, setCurrent] = useState(0);
  const [verifying, setVerifying] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const cam = useCamera();
  useEffect(() => { cam.start("environment"); return () => cam.stop(); }, []);

  const verify = async () => {
    const frame = cam.capture();
    if (!frame) return;
    setVerifying(true);
    try {
      const res = await verifyStepImage({ imageBase64: frame, stepText: steps[current] });
      setFeedback(`${Math.round(res.confidence * 100)}% · ${res.feedback}`);
      if (res.confidence > 0.8 && current < steps.length - 1) setCurrent((c) => c + 1);
    } catch (e: any) {
      setFeedback(`Error: ${e.message}`);
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_420px]">
      <div className="space-y-4">
        <h1 className="text-2xl font-semibold">{title}</h1>
        <ol className="list-decimal space-y-2 pl-6">
          {steps.map((s, i) => (
            <li key={i} className={i === current ? "font-semibold text-white" : "text-white/80"}>{s}</li>
          ))}
        </ol>
        <div className="flex gap-2">
          <button className="btn btn-outline" disabled={current === 0} onClick={() => setCurrent((c) => Math.max(0, c - 1))}>Prev</button>
          <button className="btn btn-primary" onClick={verify} disabled={verifying}>{verifying ? "Verifying…" : "Verify Step"}</button>
          <button className="btn btn-outline" disabled={current >= steps.length - 1} onClick={() => setCurrent((c) => Math.min(steps.length - 1, c + 1))}>Next</button>
        </div>
        {feedback && <div className="text-sm text-white/80">{feedback}</div>}
      </div>
      <div className="space-y-3">
        <CameraPreview hook={cam} />
        <div className="text-sm text-white/70">Camera verification uses an Edge Function that calls Gemini with the current step text.</div>
      </div>
    </div>
  );
}
