export default function Favorites() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Favorites</h1>
      <p className="text-white/70">Your bookmarked instructions will appear here.</p>
    </div>
  );
}
