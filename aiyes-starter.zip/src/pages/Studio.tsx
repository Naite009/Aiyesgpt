import { useCamera, CameraPreview } from "@/components/Camera";
import { useState } from "react";

export default function Studio() {
  const cam = useCamera();
  const [facing, setFacing] = useState<"user" | "environment">("user");

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold">Lesson Studio</h1>
      <div className="flex gap-2">
        <button className="btn btn-outline" onClick={() => cam.start(facing)}>Start Camera</button>
        <button className="btn btn-outline" onClick={() => cam.stop()}>Stop</button>
        <button className="btn btn-outline" onClick={() => setFacing(facing === "user" ? "environment" : "user")}>Flip</button>
      </div>
      <CameraPreview hook={cam} />
      <div className="flex gap-2">
        <button className="btn btn-primary" onClick={() => {
          const b64 = cam.capture();
          if (b64) download(b64, `frame-${Date.now()}.jpg`);
        }}>Capture Frame</button>
      </div>
    </div>
  );
}

function download(dataUrl: string, filename: string) {
  const a = document.createElement("a");
  a.href = dataUrl; a.download = filename; a.click();
}
