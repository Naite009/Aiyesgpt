import NavSearch from "@/components/NavSearch";
import InstructionCard from "@/components/InstructionCard";
import { useAppStore } from "@/store";

export default function Browse() {
  const { searchQuery, setSearchQuery, instructions } = useAppStore();
  const filtered = instructions.filter((i) =>
    i.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    i.tags?.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-semibold">Browse</h1>
        <NavSearch value={searchQuery} onChange={setSearchQuery} />
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((it) => (
          <InstructionCard key={it.id} item={it} />
        ))}
        {filtered.length === 0 && (
          <div className="text-white/70">No results yet. Create your first instruction →</div>
        )}
      </div>
    </div>
  );
}
