import { useMemo, useState } from "react";
import { parseStepsFromMarkdown } from "@/services/ai";

interface Q { id: string; prompt: string; options?: string[]; answer?: number; type: "mc" | "practical" }

export default function TestMode() {
  // TODO: fetch instruction
  const [md] = useState("1. Step one\n2. Step two");
  const steps = useMemo(() => parseStepsFromMarkdown(md), [md]);
  const questions: Q[] = [
    { id: "q1", type: "mc", prompt: `What comes first?`, options: steps, answer: 0 },
    { id: "q2", type: "practical", prompt: `Show the result of step: ${steps[1]}` },
  ];
  const [score, setScore] = useState(0);

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold">Test Mode</h1>
      <div className="space-y-3">
        {questions.map((q, idx) => (
          <div key={q.id} className="card p-4">
            <div className="mb-2 text-sm text-white/60">Question {idx + 1}</div>
            <div className="font-medium">{q.prompt}</div>
            {q.type === "mc" && (
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                {q.options?.map((opt, i) => (
                  <button key={i} className="btn btn-outline" onClick={() => setScore((s) => s + (i === q.answer ? 1 : 0))}>{opt}</button>
                ))}
              </div>
            )}
            {q.type === "practical" && (
              <div className="mt-2 text-sm text-white/70">Use Guided Mode to verify practical answers.</div>
            )}
          </div>
        ))}
      </div>
      <div className="text-white/80">Score: {score} / {questions.filter(q => q.type === "mc").length}</div>
    </div>
  );
}
