import { useState } from "react";
import { supabase } from "@/lib/supabase";

export default function Create() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("1. Step one\n2. Step two\n- Optional tip");
  const [category, setCategory] = useState("General");
  const [tags, setTags] = useState("howto,guide");
  const [isPublic, setIsPublic] = useState(true);
  const [saving, setSaving] = useState(false);

  const onSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase.from("instructions").insert({
        title,
        content,
        category,
        tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
        is_public: isPublic,
      });
      if (error) throw error;
      alert("Saved!");
      setTitle(""); setContent("");
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold">Create Instruction</h1>
      <input className="input" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <textarea className="input min-h-[160px]" value={content} onChange={(e) => setContent(e.target.value)} />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <input className="input" placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} />
        <input className="input" placeholder="tags (comma-separated)" value={tags} onChange={(e) => setTags(e.target.value)} />
      </div>
      <label className="flex items-center gap-2 text-sm text-white/80">
        <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} /> Public
      </label>
      <div className="flex gap-2">
        <button onClick={onSave} disabled={saving} className="btn btn-primary">{saving ? "Saving…" : "Save"}</button>
        <button className="btn btn-outline">Attach File (TODO)</button>
      </div>
    </div>
  );
}
