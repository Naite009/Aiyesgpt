export interface Instruction {
  id: string;
  title: string;
  content: string; // Markdown or structured steps
  category: string;
  tags: string[];
  isPublic: boolean;
  createdBy: string;
  createdAt: string;
  fileUrl?: string;
  fileName?: string;
  isBookmarked?: boolean;
}

export interface Step {
  id: string;
  content: string;
  completed: boolean;
  verified: boolean;
  confidence?: number;
  verificationData?: any;
}

export interface VerificationResult {
  stepId: string;
  confidence: number;
  feedback: string;
  timestamp: string;
  imageData?: string;
}

export interface UserProgress {
  userId: string;
  instructionId: string;
  currentStep: number;
  completedSteps: number[];
  verificationResults: VerificationResult[];
}
