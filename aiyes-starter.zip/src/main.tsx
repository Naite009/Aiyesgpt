import React from "react";
import ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./index.css";
import App from "./App";
import Browse from "./pages/Browse";
import Create from "./pages/Create";
import Studio from "./pages/Studio";
import Guided from "./pages/Guided";
import TestMode from "./pages/TestMode";
import Favorites from "./pages/Favorites";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { index: true, element: <Browse /> },
      { path: "browse", element: <Browse /> },
      { path: "create", element: <Create /> },
      { path: "studio", element: <Studio /> },
      { path: "guided/:id", element: <Guided /> },
      { path: "test/:id", element: <TestMode /> },
      { path: "favorites", element: <Favorites /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
