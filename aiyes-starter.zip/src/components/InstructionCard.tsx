import { BookMarked, Play, Video } from "lucide-react";
import type { Instruction } from "@/types";
import { Link } from "react-router-dom";

export default function InstructionCard({ item }: { item: Instruction }) {
  return (
    <div className="card p-4">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-lg font-semibold">{item.title}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-white/70">{item.content}</p>
        </div>
        <button className="btn btn-outline" title="Bookmark"><BookMarked className="size-4" /></button>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <span className="badge">{item.category}</span>
        {item.tags?.slice(0, 3).map((t) => (
          <span key={t} className="badge">#{t}</span>
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        <Link to={`/guided/${item.id}`} className="btn btn-primary"><Play className="mr-2 size-4"/> Guided</Link>
        <Link to={`/test/${item.id}`} className="btn btn-outline"><Video className="mr-2 size-4"/> Test</Link>
      </div>
    </div>
  );
}
