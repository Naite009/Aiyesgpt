import { useEffect, useRef, useState } from "react";

export function useCamera() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const start = async (facingMode: "user" | "environment" = "user") => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode }, audio: false });
    streamRef.current = stream;
    if (videoRef.current) {
      (videoRef.current as any).srcObject = stream;
      await videoRef.current.play();
      setReady(true);
    }
  };

  const stop = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    setReady(false);
  };

  const capture = (): string | null => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.8);
  };

  return { videoRef, start, stop, ready, capture };
}

export function CameraPreview({ hook }: { hook: ReturnType<typeof useCamera> }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10">
      <video ref={hook.videoRef} playsInline className="h-64 w-full bg-black object-cover" />
    </div>
  );
}
