# Aiyes – Full-stack Starter (Vite React + Supabase + Camera + Edge AI)

A quick-start repo skeleton that matches your spec. Includes:
- Vite + React 18 + TypeScript + Tailwind + lucide-react
- Supabase client + Auth UI stubs + RLS-friendly data helpers
- Pages: Browse / Create / Studio / Guided / Test / Favorites
- Camera + capture utilities (Web APIs) and mobile-friendly UX
- Edge Function: `verify_step` (Gemini call placeholder)
- Types + state scaffolding + basic store

## Quickstart
1. `pnpm i` (or `npm i` / `yarn`)
2. copy `.env.example` → `.env` and set keys
3. `pnpm dev`
4. (optional) `supabase functions deploy verify_step`
5. Paste `supabase/schema.sql` into Supabase SQL editor and run

## Deploy
- Vercel (recommended). Set `VITE_*` env vars.

## Notes
- This scaffold keeps styling light; you can add shadcn/ui later (`npx shadcn@latest init`).
