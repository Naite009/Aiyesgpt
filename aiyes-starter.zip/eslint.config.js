export default [
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: { ecmaVersion: 2022 },
    rules: {}
  }
];
